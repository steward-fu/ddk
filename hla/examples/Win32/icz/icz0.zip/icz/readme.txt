"Iczelion's tutorials"

There are two RadASM projects per directory.

The "standard" RadASM project file is set up for 
using Borland's make, the second one for
Microsoft's nmake.exe program.

------------------------------------------------
Standard Build via make.exe: <<file>>.rap

This version assumes that you've installed Borland's
make.exe (or some equivalent program named make.exe)
in your execution path (e.g., the HLA subdirectory).

This project file uses the "makefile" file to control
the assembly options found in the RadASM "MAKE" menu.

------------------------------------------------
Build via nmake.exe: <<file>>_nmake.rap

This version assumes that you've installed Microsoft's
nmake.exe in your execution path (e.g., the HLA 
subdirectory).

This project file uses the "makefile" file to control
the assembly options found in the RadASM "MAKE" menu.

------------------------------------------------