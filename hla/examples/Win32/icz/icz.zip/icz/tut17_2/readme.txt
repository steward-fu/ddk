There are three RadASM projects in this directory
and several batch files to provide different options
for RadASM and command-line users.

"Iczelion's tutorials for HLA" assumes that you're
using a make program (typically Borland's make.exe
software) and the "standard" RadASM project file is
set up for using Borland's make.

Some users have Microsoft's nmake.exe program.
Some users don't have a version of make at all.

The extra RadASM project files found in this
directory and the batch files are for those
users who prefer not to use Borland's make.exe
program.


------------------------------------------------
Standard Build via make.exe: tut17_2.rap

This version assumes that you've installed Borland's
make.exe (or some equivalent program named make.exe)
in your execution path (e.g., the HLA subdirectory).

This project file uses the "makefile" file to control
the assembly options found in the RadASM "MAKE" menu.

------------------------------------------------
Build via nmake.exe: tut17_2_nmake.rap

This version assumes that you've installed Microsoft's
nmake.exe in your execution path (e.g., the HLA 
subdirectory).

This project file uses the "makefile" file to control
the assembly options found in the RadASM "MAKE" menu.

------------------------------------------------
Batch Files: tut17_2_bat.rap

The typewriter_bat.rap file invokes batch files
to do the compilation rather than make or nmake.
The RadASM make menu items do the following

BUILD- invokes build.bat
BUILD ALL - invokes build.bat
COMPILE RC - invokes compilerc.bat
SYNTAX - invokes syntax.bat

Note that these batch files always recompile
the application, even if the current object
files and executables are up to date (i.e.,
you don't get the benefits of using the make
utility here). Not that it really matters
for such a small program.

You can also invoke these batch files directly from
a command window shell prompt if you don't have
a make utility available.

------------------------------------------------